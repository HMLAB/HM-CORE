//////////////////////////////////////////////////////////////////////////////////
//   __ ____  _____   ___   ___ 
//  / // /  |/  / /  / _ | / _ )
// / _  / /|_/ / /__/ __ |/ _  |
///_//_/_/  /_/____/_/ |_/____/ 
//
// Company: HMLAB
// Engineer: likw
// Create Date: 2018/04/17 23:45:11
// Design Name: hmcore devicetree
// Description: devicetree files for hmcore
// Revision:    V180417 - File Created
// Additional Comments:For more information, please visit: www.hm-lab.com/hm-core
//////////////////////////////////////////////////////////////////////////////////


1.HM-CORE BIST devicetree file generate by Petalinux.