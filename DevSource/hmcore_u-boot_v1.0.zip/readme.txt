//////////////////////////////////////////////////////////////////////////////////
//   __ ____  _____   ___   ___ 
//  / // /  |/  / /  / _ | / _ )
// / _  / /|_/ / /__/ __ |/ _  |
///_//_/_/  /_/____/_/ |_/____/ 
//
// Company: HMLAB
// Engineer: likw
// Create Date: 2018/04/17 23:34:23
// Design Name: hmcore u-boot
// Description: u-boot files for hmcore
// Revision:    V180417 - File Created
// Additional Comments:For more information, please visit: www.hm-lab.com/hm-core
//////////////////////////////////////////////////////////////////////////////////


1.HM-CORE U-BOOT file generate by Petalinux.