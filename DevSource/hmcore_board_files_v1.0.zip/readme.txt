//////////////////////////////////////////////////////////////////////////////////
//   __ ____  _____   ___   ___ 
//  / // /  |/  / /  / _ | / _ )
// / _  / /|_/ / /__/ __ |/ _  |
///_//_/_/  /_/____/_/ |_/____/ 
//
// Company: HMLAB
// Engineer: likw
// Create Date: 2018/03/31 20:13:21
// Design Name: hmcore_board_files
// Description: vivado board files for hmcore
// Revision:    V180331 - File Created
// Additional Comments:For more information, please visit: www.hm-lab.com/hm-core
//////////////////////////////////////////////////////////////////////////////////


1.copy folder hmcore to your vivado installation path, such as:

Windows: D:\Xilinx\Vivado\2016.4\data\boards\board_files
Linux:   /home/Xilinx/Vivado/2016.4/data/boards/board_files

